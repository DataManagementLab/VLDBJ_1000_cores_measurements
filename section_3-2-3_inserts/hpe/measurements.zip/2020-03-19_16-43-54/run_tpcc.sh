#!/bin/bash

# Disable core dump!
ulimit -S -c 0

export LD_LIBRARY_PATH="./libs;./build/tbb_cmake_build/tbb_cmake_build_subdir_release/"
#export LD_LIBRARY_PATH="./build/tbb_cmake_build/tbb_cmake_build_subdir_release/"

# Default values
WHs="1024"
threads="1 2 4"
remote_news="1" # Default TPC-C (implies 15 perc. remote payment)
CCs="WAIT_DIE NO_WAIT DL_DETECT TIMESTAMP MVCC HEKATON HSTORE OCC VLL TICTOC SILO"
NO_HTs="0" # Only with hyperthreading
SMALLs="0" # Run only small relations
BACKOFFs="0" # Only original waiting/deadlock detection
PROC_BIND="close"

resdir=`date +%F_%H-%M-%S`
mkdir ${resdir}

# Load custom config values from config file
if [ -r "${1}" ];then
	source "${1}"
	cp "${1}" "${resdir}"
else
	echo "Provide configuration file!"
	echo -e "\a"
	exit 1
fi

cp ${0} ${resdir}

{
	# Disable core dump!
	ulimit -S -c 0

	# Deactivate Watch Dog to free performance counter for CacheMeter
	su -c "echo 0 > /proc/sys/kernel/nmi_watchdog"

	export OMP_DISPLAY_ENV="true"

	pre_exec="timeout 60m nice --18"

	export SEGFAULT_SIGNALS="all"
	pre_exec="catchsegv ${pre_exec}"

	for BACKOFF in ${BACKOFFs}; do
		for NO_HT in ${NO_HTs}; do

			if [ ${NO_HT} -eq 1 ]; then
				cpus=`nproc`
				let "cpus=cpus/2-1"
				pre_exec="${pre_exec} numactl -C0-${cpus}"
			fi

			for SMALL in ${SMALLs}; do
				for WH in ${WHs}; do
					for remote_new in ${remote_news}; do

						# Remote payment semi proportional to remote neworder
						if [ ${remote_new} -eq 0 ]; then
							remote_pay=0
						else
							let "remote_pay=15+remote_new*85/100"
						fi
						for CC in ${CCs}; do

							#sed -ir "s/#define CC_ALG.*/#define CC_ALG ${CC}/" config.h
							#make -j50

							for thread in ${threads}; do

								run="./build/rundb_${WH}_${CC}"

								if [ ${SMALL} -eq 1 ]; then
									run="${run}_SMALL"
								else
									run="${run}_FULL"
								fi

								run="${run}_${BACKOFF}"

								echo "WH=$WH CC=$CC T=$thread SMALL=$SMALL NO_HT=$NO_HT RP=$remote_pay RN=$remote_new BACKOFF=${BACKOFF}"

								out_file="${resdir}/${WH}_${CC}_${thread}_${SMALL}_${NO_HT}_${remote_pay}_${remote_new}_${BACKOFF}"

								OMP_PROC_BIND=${PROC_BIND} \
								HUBSTATS_FILE=${out_file}.hubstats.out \
								CACHE_METER_RESULT_FILE=${out_file}.cpu.csv \
								${pre_exec} ${run} -t${thread} -TrP${remote_pay} -TrN${remote_new} -o ${out_file}.result.csv &> ${out_file}.log.out

								sleep 30s

								if [ -e sdstats_registers.dat ]; then
									mv sdstats_registers.dat "${out_file}.hubstats.dat"
								elif [ -e uvstats_registers.dat ]; then
									mv uvstats_registers.dat "${out_file}.hubstats.dat"
								else
									echo "WARN: No hubstats data found"
								fi
								
							done # threads
						done # CC
					done # remote_new
				done # Warehouses
			done # SMALL and FULL
		done # NO_HT
	done # BACKOFFs

} |& tee ${resdir}/output.log

# Activate Watch Dog again
su -c "echo 1 > /proc/sys/kernel/nmi_watchdog"
